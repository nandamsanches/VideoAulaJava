package br.com.alura.java.io.test;

import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

public class TesteUnicodeEEncoding {
	public static void main(String[] args) throws UnsupportedEncodingException {
		
		
		String s = "C";
		//saber o numero associado na tabela de unicodes(codepoint)
		//0 para identificar a posi��o exata porque String pode ter varios caracteres
		System.out.println(s.codePointAt(0));
		
		//Saber qual o encoding padr�o que java usa, que est� de acordo com o so do pc
		//unicode = mapeamento do caractere
		//encoding = armazena caractere
		Charset charset = Charset.defaultCharset();
		//descobre qual encoding utilizado
		System.out.println(charset.displayName());
		
		//FORMAS DE ACHAR O CHARSET
		byte[] bytes = s.getBytes("windows-1252");
		System.out.println(bytes.length + ", windows-1252");
		
		//transforma representa��o bin�ria da string em uma dessas charsets
		//String snovo = new String(bytes, "windows-1252"); - da pra dizer qual charset quer usar
		String snovo = new String(bytes);
		System.out.println(snovo);
		
		//definir qual charset quer utilizar
		bytes = s.getBytes("UTF-16");
		System.out.println(bytes.length + ", UTF-16");
		
		bytes = s.getBytes(StandardCharsets.US_ASCII);
		System.out.println(bytes.length + ", US_ASCII");
	}
}
