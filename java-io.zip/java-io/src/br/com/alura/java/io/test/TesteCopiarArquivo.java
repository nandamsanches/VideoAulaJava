package br.com.alura.java.io.test;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.net.Socket;


public class TesteCopiarArquivo {
	public static void main(String[] args) throws IOException {
		//forma em rede (exemplo do telefone "hang loose", o dedao � o inputstream e o dedinho o output
		new Socket().getInputStream();		
		
		//Entrada (1 em teclado(console) 2 arquivo) 
		InputStream fis = System.in;//new FileInputStream("lorem.txt");
		Reader isr = new InputStreamReader(fis);
		BufferedReader br = new BufferedReader(isr);
		//Sa�da
		OutputStream fos = System.out;//new FileOutputStream("lorem2.txt");
		Writer osw = new OutputStreamWriter(fos);
		BufferedWriter bw = new BufferedWriter(osw);
		
		String linha = br.readLine();

		//ler todas as linhas e escrever em outro arquivo
		while(linha != null && !linha.isEmpty()){
			bw.write(linha);
			bw.newLine();
			//acontecer de forma imediata sem necessidade de linha em branco
			bw.flush();
			linha = br.readLine();
		}
	
		br.close();
		bw.close();
}


}

