package br.com.alura.java.io.test;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;

public class TesteEscrita3 {
	public static void main(String[] args) throws IOException {

		//Fluxo de sa�da com arquivo
//		OutputStream fos = new FileOutputStream("lorem2.txt");
//		Writer osw = new OutputStreamWriter(fos);
//		BufferedWriter bw = new BufferedWriter(osw);
		
		//FileWriter fw = new FileWriter("lorem2.txt");
		//BufferedWriter bw = new BufferedWriter(new FileWriter("lorem2.txt"));
		
		// ou coloca direto new PrintStream("lorem2.txt")
	     PrintWriter ps = new PrintWriter("lorem2.txt");
		//outro jeito PrintStream ps = new PrintStream(new File("lorem2.txt"));
		ps.println("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod");
		ps.println();
		ps.println();
		ps.println();
		ps.println("sdmkdmskmdslmsl");
		

		ps.close();
	}


}

