package br.com.alura.java.io.test;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;


//mede tempo de execu��o
public class TesteEscritaFileWriter {
public static void main(String[] args) throws IOException {
	
    long ini = System.currentTimeMillis();

//
//	//Fluxo de sa�da com arquivo
//	OutputStream fos = new FileOutputStream("lorem2.txt");
//	Writer osw = new OutputStreamWriter(fos);
//	BufferedWriter bw = new BufferedWriter(osw);

	//FileWriter fw = new FileWriter("lorem2.txt");
	BufferedWriter bw = new BufferedWriter(new FileWriter("lorem2.txt"));
	bw.write("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod");
	//o mesmo que fw.write("\r\n");
	bw.write(System.lineSeparator());
	bw.write(System.lineSeparator());
	bw.write("sdmkdmskmdslmsl");

	bw.close();
	
	long fim = System.currentTimeMillis();

	System.out.println("Passaram " + (fim - ini) + " milissegundos");
}


}

