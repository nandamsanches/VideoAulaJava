package br.com.bytebank.banco.teste;

public class TesteString {
	
	public static void main(String[] args) {
		String nome = "Alura";
		
		nome.replace("A", "a");
		
		String outra = nome.replace("A", "a");
		
		//String outra = nome.toUpperCase();
		
		
		
		System.out.println(nome);
		System.out.println(outra);
	}
}
