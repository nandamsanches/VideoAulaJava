
public class TesteFuncionario {

	public static void main(String[] args) {
		Gerente funcionario = new Gerente();
		funcionario.setNome("Nico");
		funcionario.setCpf("232323");
		funcionario.setSalario(2600.00);

		System.out.println(funcionario.getNome());
		System.out.println(funcionario.getBonificacao());


}

}
